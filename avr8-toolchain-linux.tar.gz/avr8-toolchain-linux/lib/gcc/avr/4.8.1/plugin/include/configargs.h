/* Generated automatically. */
static const char configuration_arguments[] = "/home/jenkins/workspace/avr8-gnu-toolchain/src/gcc/configure LDFLAGS=-L/home/jenkins/workspace/avr8-gnu-toolchain/avr8-gnu-toolchain-linux_x86/lib CPPFLAGS= --target=avr --host=i686-pc-linux-gnu --build=x86_64-pc-linux-gnu --prefix=/home/jenkins/workspace/avr8-gnu-toolchain/avr8-gnu-toolchain-linux_x86 --libdir=/home/jenkins/workspace/avr8-gnu-toolchain/avr8-gnu-toolchain-linux_x86/lib --enable-languages=c,c++ --with-dwarf2 --enable-doc --disable-shared --disable-libada --disable-libssp --disable-nls --with-avrlibc=yes --with-mpfr=/home/jenkins/workspace/avr8-gnu-toolchain/avr8-gnu-toolchain-linux_x86 --with-gmp=/home/jenkins/workspace/avr8-gnu-toolchain/avr8-gnu-toolchain-linux_x86 --with-mpc=/home/jenkins/workspace/avr8-gnu-toolchain/avr8-gnu-toolchain-linux_x86 --enable-fixed-point --with-pkgversion=AVR_8_bit_GNU_Toolchain_3.4.5_1522 --with-bugurl=http://www.atmel.com";
static const char thread_model[] = "single";

static const struct {
  const char *name, *value;
} configure_default_options[] = { { NULL, NULL} };
